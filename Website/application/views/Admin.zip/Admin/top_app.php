<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="<?php echo base_url(); ?>assets/css/stylee.css" rel="stylesheet" type="text/css" media="all"/>
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.9.0.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/move-top.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/easing.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.nivo.slider.js"></script>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
<script src="<?php echo base_url(); ?>assets/js/ddmenu.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/rating_review.js"></script> 
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/paging.js"></script>
<style type="text/css">    
            .pg-normal {
                color: black;
                font-weight: normal;
                text-decoration: none;    
                cursor: pointer;    
            }
            .pg-selected {
                color: black;
                font-weight: bold;        
                text-decoration: underline;
                cursor: pointer;
            }
        </style>

</head>
<body>
	<div class="header">
		 <div class="headertop_desc">
			<div class="wrap">
				<div class="nav_list">
					
				</div>
					
				<div class="clear"></div>
			</div>
	  	</div>
  	  		<div class="wrap">
				<div class="header_top">

					<div class="logo">

						<a href="<?php echo base_url();?>index.php/StarAdmin/home"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="" /></a>

					</div>

						<div class="header_top_right">

						<div class="search_box">

					     		<form>

					     			<input type="text" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}"><input type="submit" value="">

					     		</form>

					     	</div>

						
						  <div class="account_desc">

						<ul>						

							

							<li><a  href="<?php echo base_url();?>index.php/StarAdmin/apps">My Apps</a></li>

							<li><a href="<?php echo base_url();?>index.php/StarAdmin/contact">Contact</a></li>

							<li><a href="<?php echo base_url();?>index.php/StarAdmin/register">Register</a></li>

							<li><a href="<?php echo base_url();?>index.php/StarAdmin/login">Login</a></li>
							
							<li><a href="<?php echo base_url();?>index.php/StarAdmin/favourite">Favourite Apps</a></li>

						</ul>

					</div>

							  
						 <div class="clear"></div>

					</div>

						  <script type="text/javascript">

								function DropDown(el) {

									this.dd = el;

									this.initEvents();

								}

								DropDown.prototype = {

									initEvents : function() {

										var obj = this;

					

										obj.dd.on('click', function(event){

											$(this).toggleClass('active');

											event.stopPropagation();

										});	

									}

								}

					

								$(function() {

					

									var dd = new DropDown( $('#dd') );

					

									$(document).click(function() {

										// all dropdowns

										$('.wrapper-dropdown-2').removeClass('active');

									});

					

								});

					    </script>

			   <div class="clear"></div>

  		    </div> 

<div class="content_top">
    		<div class="back-links">
			
			<nav id="ddmenu">
    <div class="menu-icon"></div>
    <ul>
        <li class="full-width">
            <a class="top-heading active">Category</a>
            <i class="fa fa-caret-down" aria-hidden="true"></i>
            <div class="dropdown">
                <div class="dd-inner">
				<?php			
			foreach($Cat->Result() as $row){?>
                    <ul class="column">                        
                        <li><a href="#"><?php echo $row->name; ?></a></li>					 
                    </ul>
					<?php } ?>
                 
                </div>
            </div>
        </li>
       <li class="no-sub"><a class="top-heading active" href="<?php echo base_url();?>index.php/StarAdmin/home">Home</a></li>
        <li>
            <a class="top-heading active" href="<?php echo base_url();?>index.php/StarAdmin/top_app">Top Chart</a>
            
        </li>
        <li>
            <a class="top-heading active" href="<?php echo base_url();?>index.php/StarAdmin/top_down">Top Downloads</a>
           
            
        </li>
        <li class="no-sub">
            <a class="top-heading active" href="<?php echo base_url();?>index.php/StarAdmin/cat_app">New Releases</a>
        </li>
		<li class="no-sub">
            <a class="top-heading active" href="<?php echo base_url();?>index.php/StarAdmin/top_rating">Top Ratings</a>
        </li>
		<li class="no-sub">
            <a class="top-heading active" href="<?php echo base_url();?>index.php/StarAdmin/top_favourite">Top Favourite</a>
        </li>
    </ul>
</nav>
			
			
			
			 </div>
    		<div class="clear"></div>
    	</div>


			
				<div class="header_bottom">
					<div class="header_bottom_left">				
						<div class="categories">
						  
						</div>					
		  	         </div>
						   
			     <div class="clear"></div>
			</div>
   		</div>
   </div>
	       <!------------End Header ------------> 
		
    	 <div class="main">
  	<div class="wrap">
      <div class="content">
    	<div class="">
    		<div class="heading">
    		<h2  class="heading">Top Apps</h2>
    		</div>
    	</div>
	      <div class="section group">
		   <?php foreach($top_app->Result() as $data){?>
				<div class="grid_1_of_5 images_1_of_5">
				
					<a href="<?php echo base_url(); ?>index.php/StarAdmin/preview/<?php echo $data->ref; ?>"><img src="http://superhtv.com/IT_APPP/image/App/<?php echo $data->app_image; ?>" alt="" /></a>
					<h5 class="mess"><?php echo $data->appname; ?></h5>
					 <h6 class="mess"><?php echo $data->name; ?></h6>
					<div class="price-details">
					<?php if ($data->rank == 1){ ?>
				       <div class="staricon">								
									<i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
									 </div>
									 <?php } ?>
									 <?php if ($data->rank == 2){ ?>
				       <div class="staricon">								
									<i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
									 </div>
									 <?php } ?>
									 <?php if ($data->rank == 3){ ?>
				       <div class="staricon">								
									<i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
									 </div>
									 <?php } ?>
									 <?php if ($data->rank == 4){ ?>
				       <div class="staricon">								
									<i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star-o" aria-hidden="true"></i>
									 </div>
									 <?php } ?>
									 <?php if ($data->rank == 5){ ?>
				       <div class="staricon">								
									<i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
								   <i class="fa fa-star" aria-hidden="true"></i>
									 </div>
									 <?php } ?>
									 <div>
									<h5 class="aa_to_desc">
									<button id="demo" onclick="myFunction()"><i class="fa fa-heart" aria-hidden="true"></i> Add to Wishlist</button>
									
									</h5> 
							    </div>
							
							 <div class="clear"></div>
					</div>
		

		
				</div>
					<?php } ?>
				
			</div>
			 <div id="pageNavPosition"></div>
		<script>
function myFunction() {
    document.getElementById("demo").innerHTML = "Browse Wishlist";
}
</script>			
		<div id="pageNavPosition"></div>
		<script type="text/javascript"><!--
        var pager = new Pager('results', 3); 
        pager.init(); 
        pager.showPageNav('pager', 'pageNavPosition'); 
        pager.showPage(1);
    //--></script>	
			
  	</div>
	</div>
			
       </div>
 
<br>
<br>
<br><br>
<br>
<br><br>
<br>
<br>


